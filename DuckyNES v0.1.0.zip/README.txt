DuckyNES (CatScape Technologies 2024 Revision)
--------------------------------------------
THIS SOFTWARE HAS NOT BEEN MODIFIED (except for the audio patch) IN ANYWAY.
IT IS STILL RUNNING VERSION 0.1.0. THERE WILL BE NO UPDATES TO THIS SOFTWARE.
--------------------------------------------

This emulator is a very early emulator being powered by Visual Basic 6.0. It runs alright but the audio does has some issues with crackling or being off tuned. Don't contact me about issues with DuckyNES as I'm no longer offering support for it. There is no source code since the backup of the source code has been lost due to hard drive failure.

---------------------------------------------

Controls
----------
PLAYER 1 Controls
A Button = X
B Button = Z
D-Pad = Arrow Keys
Start = Enter (Return)
Select = Probably Right Shift (if not, try "\")

PLAYER 2 Controls
Probably not mapped to the keyboard at all.
This can be configured in DuckyNES.


FAQ
----------

Q - Can you play with two players?
A - Yes, you can play with two players using the "same" keyboard.

Q - Why is it so slow?
A - Visual Basic 6.0.

Q - Why is there no audio?
A - This can happen to people using DuckyNES.
    You will need to run the DuckyNES Audio Patch to fix the audio issue.
    (Will not fix crackling and off tune audio)
    
-----------------------------------------------

SPECS
----------
You will need a medium powerful CPU to run DuckyNES.
Modern CPU should be more than enough to run DuckyNES.

DO NOT USE AN INTEL ATOM. THAT IS THE WORST CPU TO BE USING AS A DAILY DRIVER!

-----------------------------------------------

Version History
---------------------

v0.1.0
Initial release of DuckyNES.

-----------------------------------------------